### 💖&ensp;Download Source Code [(FAQ)](https://github.com/JohannesMilke/sponsorware "FAQ")

You need to click [REQUEST](https://johannesmilke.com/#/request "REQUEST") first, before you will get access to [THIS Source Code](https://github.com/JohannesMilke-Sponsors/flutter_slidable_example "THIS Source Code") and of all my other Flutter Videos.

[<img alt="JohannesMilke | REQUEST" height="40px" src="https://firebasestorage.googleapis.com/v0/b/web-johannesmilke.appspot.com/o/other%2Fgithub%2Fsponsored%2Fbutton_request.png?alt=media" />](https://johannesmilke.com/#/request "REQUEST")&ensp;[<img alt="JohannesMilke | ACCESS" height="40px" src="https://firebasestorage.googleapis.com/v0/b/web-johannesmilke.appspot.com/o/other%2Fgithub%2Fsponsored%2Fbutton_access.png?alt=media" />](https://github.com/JohannesMilke-Sponsors/flutter_slidable_example "ACCESS")

<a href="https://johannesmilke.com/#/request"><img src="https://user-images.githubusercontent.com/44921899/117563862-f5d05e80-b0a8-11eb-87fe-6453d8ef6336.jpg" 
alt="Get Access To Source Code" width="720" border="10" /></a>