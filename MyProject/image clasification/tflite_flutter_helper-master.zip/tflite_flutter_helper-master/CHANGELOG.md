# [0.2.0] - Migrate to null-safety
* Stable null-safety
* Depends on tflite_flutter: ^0.8.0
* Custom Crop position in ResizeWithCropOrPad

# [0.1.2] - BoundingBox bfix

* Fixed bounding box orderedValues

# [0.1.1] - TFLite Flutter dependency update

* Updated to tflite_flutter: ^0.5.0

# [0.1.0] - TFLite Flutter Helper

* Initial release.
