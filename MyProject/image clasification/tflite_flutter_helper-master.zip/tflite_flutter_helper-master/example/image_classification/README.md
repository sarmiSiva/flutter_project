# Image Classification Flutter App

Image Classification Example.

![Demo](demo.gif)

